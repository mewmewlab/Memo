import{R as t,A as n}from"./Ba0w2IWj.js";function o(r,e){throw new t(r,e.toString())}new TextEncoder;function a(r,e){return new n(r,e)}export{a as f,o as r};
