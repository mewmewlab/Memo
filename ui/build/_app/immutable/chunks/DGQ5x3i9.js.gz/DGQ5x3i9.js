import{V as a}from"./DDkSnQK4.js";a();
